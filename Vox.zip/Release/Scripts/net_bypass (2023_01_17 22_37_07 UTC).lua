for i,v in next, game:GetService("Players").LocalPlayer.Character:GetDescendants() do
if v:IsA("BasePart") and v.Name ~="HumanoidRootPart" then 
game:GetService("RunService").Heartbeat:connect(function()
v.Velocity = Vector3.new(30,0,0)
end)
end
end

game:GetService("RunService").RenderStepped:Connect(function()
    sethiddenproperty(game.Players.LocalPlayer, "SimulationRadius", math.huge)
     sethiddenproperty(game.Players.LocalPlayer, "MaximumSimulationRadius", math.huge)
end)
