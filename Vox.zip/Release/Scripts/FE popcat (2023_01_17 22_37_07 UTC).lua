--[[
Made By Ice & Fire
Discord: Ice & Fire#0001
Roblox: 09Ice_Fire09

The Pop Cat!

Controls:
e= sit, q= pop
r= wave
t= punch
f= idk
g= punch from black
z= yes
x= no

Hats:
https://www.roblox.com/catalog/6380246734/Pop-Cat
https://www.roblox.com/catalog/6065706256/Pop-Cat-Hoodie
https://www.roblox.com/catalog/8337370/Blockhead-Baseball-Cap
https://www.roblox.com/catalog/48474313/Red-Roblox-Cap
https://www.roblox.com/catalog/48474294/ROBLOX-Girl-Hair
https://www.roblox.com/catalog/62724852/Chestnut-Bun
https://www.roblox.com/catalog/451220849/Lavender-Updo
https://www.roblox.com/catalog/62234425/Brown-Hair
Cost: 133 Bobux

Made By Ice & Fire
Discord: Ice & Fire#0001
Roblox: 09Ice_Fire09
]]










loadstring(game:HttpGet(('https://raw.githubusercontent.com/hacker123454/x/main/Pop_Cat.txt'),true))()