while wait() do 
game:GetService('VirtualInputManager'):SendKeyEvent(true,'',false,uwu)
end