density = 100
char = game.Players.LocalPlayer.Character

for _, child in pairs(char:GetDescendants()) do
if child.ClassName == "Part" then
child.CustomPhysicalProperties = PhysicalProperties.new(density, 0.3, 0.5)
end
end