loadstring(game:HttpGet(('https://pastebin.com/raw/9qnY2Fwp'),true))()
--modes :
-- Press Q : typing mode, Press Q again : Switch back to Normal mode/end
-- Press E : Remote Hand Raise, Press E again : Switch back to Normal mode/end
-- re-execute the script if it's broken or laggy/buggy.
-- https://www.roblox.com/catalog/376526673/Stylish-Aviators

-- https://www.roblox.com/catalog/376524487/Blonde-Spiked-Hair

-- https://www.roblox.com/catalog/6470135113/Fan-Hand-Sign-Why-Dont-We-WDW

-- https://www.roblox.com/catalog/62724852/Chestnut-Bun

-- https://www.roblox.com/catalog/48474294/ROBLOX-Girl-Hair

-- https://www.roblox.com/catalog/376527500/Orange-Shades

-- https://www.roblox.com/catalog/9350274205/Vans-Black-White-Checkerboard-Umbrella

-- [  You can get this from https://www.roblox.com/games/6679274937/Vans-World-S2 game, goto the beach and seaech umbrella ] --

-- https://www.roblox.com/catalog/9661543986/Nike-Shoebox-Costume

-- [join to this game : https://www.roblox.com/games/7462526249/NIKELAND-UPDATE and search for cake > eat > get rewarded or watch tutorials on YouTube] --

-- https://www.roblox.com/catalog/2309346267/Classic-PC-Hat

-- [ get this hat from https://www.roblox.com/games/2546610365/Roblox-Creator-Challenge and complete all challenges by answering 3-4 questions correctly in every stage.]