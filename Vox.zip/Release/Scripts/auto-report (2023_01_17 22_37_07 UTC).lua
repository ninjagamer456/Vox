getgenv().autoreport = {
       Advertise = false,
      Safe = false,
       Webhook = "https://discord.com/api/webhooks/1037931901865951232/OyS0XxyKHbbUawzDWvKE8lLOmMNL0T4KZ_jLuLg_9lQ2ig_8oQMZo31SopunAt40FNZi"
};
loadstring(game:HttpGet("https://raw.githubusercontent.com/CF-Trail/Auto-Report/main/ar"))()