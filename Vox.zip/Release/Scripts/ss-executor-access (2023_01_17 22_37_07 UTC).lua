local args = {
    [1] = "require(2670071430).load(\"TuckModz\") "
}

game:GetService("Players").LocalPlayer.PlayerGui.MainModule:FindFirstChild("Red SS").Frame1.herobrine:FireServer(unpack(args))
